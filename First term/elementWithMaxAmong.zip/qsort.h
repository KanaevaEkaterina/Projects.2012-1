#pragma once

void qsort(int left, int right, int mass[]);