#pragma once

void merge1(List * list, int len1, int len2, ListElement * beg);

void mergeSort(List * list, ListElement * beg, int len, int parametr);